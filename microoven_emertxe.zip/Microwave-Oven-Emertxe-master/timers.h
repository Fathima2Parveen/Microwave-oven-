/* 
 * File:   timers.h
 * Author: Komala
 *
 * Created on 13 September, 2023, 6:42 PM
 */

#ifndef TIMERS_H
#define	TIMERS_H


void init_timer2(void);

#endif	/* TIMERS_H */

